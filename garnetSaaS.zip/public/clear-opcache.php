<?php opcache_reset(); echo "done";
